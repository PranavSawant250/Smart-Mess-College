import { firebaseConfig } from './firebase-config.js';
import { initializeApp } from "https://www.gstatic.com/firebasejs/10.8.0/firebase-app.js";
import { getFirestore, collection, getDocs, doc, setDoc, updateDoc, onSnapshot, query, where } from "https://www.gstatic.com/firebasejs/10.8.0/firebase-firestore.js";
import { getAuth, onAuthStateChanged, signOut } from "https://www.gstatic.com/firebasejs/10.8.0/firebase-auth.js";

// Initialize Firebase
const app = initializeApp(firebaseConfig);
const db = getFirestore(app);
const auth = getAuth(app);

// State Variables
let sidebarCollapsed = false;
let isDark = false;
let currentPage = 'dashboard';
let chartInstances = {};

// DOM Elements
const sb = document.getElementById('sidebar');
const main = document.getElementById('main');
const tb = document.getElementById('topbar');
const overlay = document.getElementById('overlay');
const pageContent = document.getElementById('page-content');

// --- Event Listeners for UI ---
document.getElementById('toggle-btn').addEventListener('click', toggleSidebar);
document.getElementById('theme-btn').addEventListener('click', toggleTheme);
overlay.addEventListener('click', closeMobileSidebar);

document.querySelectorAll('.nav-item').forEach(item => {
    item.addEventListener('click', (e) => {
        if(item.id === 'logout-btn') {
            handleLogout();
            return;
        }
        const page = item.getAttribute('data-page');
        if(page) setPage(page, item);
    });
});

// --- UI Functions ---
function toggleSidebar() {
  if (window.innerWidth <= 640) {
    sb.classList.toggle('mobile-open');
    overlay.style.display = sb.classList.contains('mobile-open') ? 'block' : 'none';
  } else {
    sidebarCollapsed = !sidebarCollapsed;
    sb.classList.toggle('collapsed', sidebarCollapsed);
    main.classList.toggle('collapsed', sidebarCollapsed);
    tb.classList.toggle('collapsed', sidebarCollapsed);
  }
}

function closeMobileSidebar() {
  sb.classList.remove('mobile-open');
  overlay.style.display = 'none';
}

function toggleTheme() {
  isDark = !isDark;
  document.documentElement.setAttribute('data-theme', isDark ? 'dark' : '');
  document.getElementById('theme-icon-sun').style.display = isDark ? 'none' : '';
  document.getElementById('theme-icon-moon').style.display = isDark ? '' : 'none';
  if(currentPage === 'dashboard') setTimeout(renderCharts, 50);
}

function setPage(page, targetElement) {
    currentPage = page;
    document.querySelectorAll('.nav-item').forEach(el => el.classList.remove('active'));
    if(targetElement) targetElement.classList.add('active');
    
    document.getElementById('topbar-title').textContent = page.charAt(0).toUpperCase() + page.slice(1).replace(/([A-Z])/g, ' $1');
    renderPage(page);
}

function handleLogout() {
    signOut(auth).then(() => {
        alert("Logged out successfully");
    }).catch((error) => {
        console.error("Error logging out:", error);
    });
}

function destroyCharts() {
  Object.values(chartInstances).forEach(c => c && c.destroy());
  chartInstances = {};
}

// --- Page Rendering ---
async function renderPage(page) {
  destroyCharts();
  pageContent.innerHTML = '<div style="text-align:center; padding: 50px;">Loading Data...</div>';
  
  try {
      if (page === 'dashboard') {
        const html = await buildDashboardHTML();
        pageContent.innerHTML = html;
        setTimeout(renderCharts, 80);
      } else if (page === 'settings') {
        pageContent.innerHTML = buildSettingsHTML();
      } else if (page === 'requests') {
        pageContent.innerHTML = buildRequestsHTML();
      } else if (page === 'attendance') {
        pageContent.innerHTML = buildAttendanceHTML();
      } else {
        pageContent.innerHTML = `<div style="display:flex;flex-direction:column;align-items:center;justify-content:center;height:300px;color:var(--text2)">
          <svg width="48" height="48" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5" style="opacity:.3;margin-bottom:12px"><rect x="3" y="3" width="18" height="18" rx="3"/><path d="M9 9h6M9 12h6M9 15h4"/></svg>
          <div style="font-size:16px;font-weight:500;margin-bottom:6px">${page.charAt(0).toUpperCase()+page.slice(1)} Page</div>
          <div style="font-size:13px">This module connects directly to Firebase. Create Firestore collections to display data here.</div>
        </div>`;
      }
  } catch (error) {
      console.error("Error loading page data:", error);
      pageContent.innerHTML = `<div style="color:var(--red); padding: 20px;">Error loading data. Please check your Firebase Configuration.</div>`;
  }
}

// --- Components ---
function badgeHtml(status){
  const map = {approved:'success',pending:'warning',rejected:'danger',paid:'success',overdue:'danger',active:'info'};
  return `<span class="badge ${map[status]||'info'}">${status.charAt(0).toUpperCase()+status.slice(1)}</span>`;
}

// --- Firebase Data Fetching & HTML Generation ---

async function buildDashboardHTML() {
  // MOCK DATA for layout (Replace with actual Firestore queries)
  // Example Firestore query: const q = query(collection(db, "requests"), where("status", "==", "pending"));
  const joinRequests = [
    {name:'Arjun Sharma',prn:'2021BCE1001',branch:'Computer Eng.',hostel:'Block A',status:'pending'},
    {name:'Priya Patel',prn:'2021ECE2034',branch:'Electronics',hostel:'Block B',status:'approved'}
  ];
  
  const reqHtml = joinRequests.map(r => `<tr>
    <td><div style="display:flex;align-items:center;gap:8px">
      <div class="av-sm" style="background:var(--primary-light);color:var(--primary)">${r.name.split(' ').map(x=>x[0]).join('')}</div>
      <span style="font-weight:500">${r.name}</span>
    </div></td>
    <td style="color:var(--text2);font-family:monospace;font-size:12px">${r.prn}</td>
    <td>${r.branch}</td>
    <td>${r.hostel}</td>
    <td>${badgeHtml(r.status)}</td>
    <td><div style="display:flex;gap:6px">
      ${r.status==='pending'?`<button class="action-btn primary" onclick="alert('Approve logic goes here (Firebase Update)')">Approve</button>`:`<button class="action-btn">View</button>`}
    </div></td>
  </tr>`).join('');

  return `
  <div class="welcome-band">
    <div style="position:relative;z-index:1">
      <div class="welcome-title">Welcome back, Admin! 👋</div>
      <div class="welcome-sub">${new Date().toLocaleDateString('en-IN',{weekday:'long',year:'numeric',month:'long',day:'numeric'})}</div>
    </div>
  </div>

  <div class="grid6" style="margin-bottom:20px">
    <div class="stat-card">
      <div><div class="stat-label">Total Students</div><div class="stat-val">342</div></div>
    </div>
    <div class="stat-card">
      <div><div class="stat-label">Pending Requests</div><div class="stat-val">7</div></div>
    </div>
  </div>

  <div class="grid3" style="margin-bottom:20px">
    <div class="card"><div class="chart-wrap"><canvas id="chartGrowth"></canvas></div></div>
    <div class="card"><div class="chart-wrap"><canvas id="chartRevenue"></canvas></div></div>
    <div class="card"><div class="chart-wrap"><canvas id="chartAttendance"></canvas></div></div>
  </div>

  <div class="card" style="overflow:hidden;padding:0">
    <div style="padding:18px 20px 12px" class="section-header">
      <div class="section-title">Recent Join Requests</div>
    </div>
    <div style="overflow-x:auto">
      <table><thead><tr><th>Name</th><th>PRN</th><th>Branch</th><th>Hostel</th><th>Status</th><th>Actions</th></tr></thead>
      <tbody>${reqHtml}</tbody></table>
    </div>
  </div>
  `;
}

function buildSettingsHTML() {
    return `
    <div class="card">
        <div class="section-header">
            <div class="section-title">Mess Settings & Payment Config</div>
        </div>
        <form id="settings-form" onsubmit="event.preventDefault(); alert('Saved to Firebase Firestore (messes/config doc)');">
            <div class="grid2">
                <div class="form-group">
                    <label class="form-label">Mess Name</label>
                    <input type="text" class="form-input" placeholder="Enter mess name">
                </div>
                <div class="form-group">
                    <label class="form-label">Monthly Fee (₹)</label>
                    <input type="number" class="form-input" placeholder="e.g. 3000">
                </div>
                <div class="form-group">
                    <label class="form-label">Owner Name</label>
                    <input type="text" class="form-input" placeholder="Owner Name">
                </div>
                <div class="form-group">
                    <label class="form-label">UPI ID</label>
                    <input type="text" class="form-input" placeholder="merchant@upi">
                </div>
            </div>
            <div class="form-group">
                <label class="form-label">Address / Description</label>
                <textarea class="form-textarea" placeholder="Mess details"></textarea>
            </div>
            <button class="action-btn primary" type="submit">Save Settings to Firebase</button>
        </form>
    </div>
    `;
}

function buildRequestsHTML() {
    return `
    <div class="card">
        <div class="section-header">
            <div class="section-title">Manage Join Requests</div>
        </div>
        <p style="margin-bottom: 20px; font-size: 13px; color: var(--text2);">
            Review student requests. Approving a request will automatically assign them a <strong>Mess Serial No.</strong> and set up their payment details.
        </p>
        <table>
            <thead><tr><th>Name</th><th>PRN</th><th>Status</th><th>Payment Proof</th><th>Actions</th></tr></thead>
            <tbody>
                <tr>
                    <td>John Doe</td>
                    <td>2021BCE001</td>
                    <td>${badgeHtml('pending')}</td>
                    <td><a href="#" style="color: var(--primary);">View Screenshot (Firebase Storage)</a></td>
                    <td>
                        <button class="action-btn primary">Approve (Assign No. 14)</button>
                        <button class="action-btn">Reject</button>
                    </td>
                </tr>
            </tbody>
        </table>
    </div>
    `;
}

function buildAttendanceHTML() {
    return `
    <div class="card">
        <div class="section-header">
            <div class="section-title">Live Attendance via Mess Serial No.</div>
        </div>
        <div class="grid2">
            <div class="card-sm" style="border: 1px solid var(--border); border-radius: 8px;">
                <label class="form-label">Enter Student Mess No.</label>
                <div style="display: flex; gap: 10px;">
                    <input type="number" class="form-input" placeholder="e.g. 14" id="mess-no-input">
                    <button class="action-btn primary" onclick="alert('Attendance Marked for Mess No: ' + document.getElementById('mess-no-input').value)">Mark Present</button>
                </div>
            </div>
            <div>
                <p style="font-size: 13px; color: var(--text2);">
                    When a student enters their Mess No, their profile is fetched from Firebase Firestore and their attendance for today's lunch/dinner is marked.
                </p>
            </div>
        </div>
    </div>
    `;
}

// Chart Render logic
function getChartColors(){
  const d = isDark;
  return { gridColor: d ? 'rgba(255,255,255,0.07)' : 'rgba(0,0,0,0.07)', tickColor: d ? '#64748b' : '#9ca3af' };
}

function renderCharts(){
  const {gridColor,tickColor} = getChartColors();
  const baseOpts = {
    responsive:true, maintainAspectRatio:false,
    plugins:{legend:{display:false}},
    scales:{
      x:{grid:{color:gridColor},ticks:{color:tickColor,font:{size:11}}},
      y:{grid:{color:gridColor},ticks:{color:tickColor,font:{size:11}}}
    }
  };

  const g1 = document.getElementById('chartGrowth');
  if(g1){
    chartInstances.growth = new Chart(g1,{
      type:'line',
      data:{
        labels:['Jan','Feb','Mar','Apr','May','Jun'],
        datasets:[{
          label:'Students', data:[290,298,308,318,330,342],
          borderColor:'#4f46e5',backgroundColor:'rgba(79,70,229,0.1)', fill:true,tension:.4
        }]
      }, options: baseOpts
    });
  }
}

// Initialize First Page
setPage('dashboard');
